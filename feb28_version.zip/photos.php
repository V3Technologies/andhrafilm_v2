<?php 
session_start();
error_reporting(0);
include('includes/config.php');

?>
<!DOCTYPE html>
<html lang="te">
<head>
<title>NewsFeed</title>
<?php include('includes/head-tag.php');?>
<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<script>
            
            function get_SingleCategoryPhotos(catid, subcatid, subcatname) {
                $.ajax({
                type: "POST",
                url: "getSingleCategoryPhoto.php",
                data:{catid: catid, subcatid: subcatid, subcatname: subcatname},
                success: function(data){
                    $(".all-photos").hide();
                    $(".subcategory-photos").html(data);
                    $(".subcategory-photos").show();
                }
                });
            }
            function showallphotos() {
              $(".all-photos").show();
              $(".subcategory-photos").hide();
            }
        </script>
</head>
<body>
  <?php include('includes/title.php');?>
  <section id="newsSection">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="latest_newsarea"> <span>Breaking News</span>
          <ul id="ticker01" class="news_sticker">
          <?php 
                $query=mysqli_query($con,"select newsid,BreakingNewsName from breakingnewstable where is_Active=1 order by CreatedTime desc LIMIT 5");
                while ($row=mysqli_fetch_array($query)) {
                ?>
                <li><a href="#"><img src="images/dotred_.png" alt=""><?php echo htmlentities($row['BreakingNewsName']);?></a></li>
            <?php } ?>
          </ul>
          <div class="social_area">
            <ul class="social_nav">
              <li class="facebook"><a href="#"></a></li>
              <li class="twitter"><a href="#"></a></li>
              <li class="youtube"><a href="#"></a></li>
              <!--<li class="flickr"><a href="#"></a></li>
              <li class="pinterest"><a href="#"></a></li>
              <li class="googleplus"><a href="#"></a></li>
              <li class="vimeo"><a href="#"></a></li>
              <li class="mail"><a href="#"></a></li> -->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_post_content all-photos">
            <h2><span>Photography</span></h2>
            <ul class="photograph_nav  wow fadeInDown">
              

              <?php
              include('includes/config.php');
              if(true) 
              {
              $query=mysqli_query($con,"select DISTINCT CONCAT(tblgallery.CategoryId, ' ',tblgallerysubcategory.SubCategoryId, ' ', tblgallery.PostingDate) as combo,tblgallery.CategoryId as catid, tblgallerysubcategory.SubCategoryId as subcatid, tblgallery.id as pid,tblgallery.posturl as posturl,tblgallerycategory.GalleryCategoryName as category,tblgallerysubcategory.Subcategory as subcategory, tblgallery.PostingDate as postingdate from tblgallery left join tblgallerycategory on tblgallerycategory.id=tblgallery.CategoryId left join tblgallerysubcategory on tblgallerysubcategory.SubCategoryId=tblgallery.SubCategoryId where tblgallery.Is_Active=1 and CONCAT(tblgallery.CategoryId, ' ',tblgallerysubcategory.SubCategoryId, ' ', tblgallery.PostingDate) in (select CONCAT(categoryid, ' ', subcategoryid, ' ', MAX(tblgallery.PostingDate)) as cat from tblgallery group by SubCategoryId) group by CONCAT(tblgallery.CategoryId, ' ',tblgallerysubcategory.SubCategoryId, ' ', tblgallery.PostingDate)");
              $cnt=1;
              $rowcount=mysqli_num_rows($query);
              if($rowcount==0)
              {
              ?>
              <div>

              <span colspan="7" align="center"><h3 style="color:red">No record found</h3></span>
              </div>
              <?php 
              } else {
              while($row=mysqli_fetch_array($query))
              {
              ?>
              <li>
                <div class="photo_grid" onClick="get_SingleCategoryPhotos(<?php echo htmlentities($row['catid']);?>, <?php echo htmlentities($row['subcatid']);?>, '<?php echo htmlentities($row['subcategory']);?>');">
                <figure class="effect-layla"> <img src="admin/postimages/<?php echo htmlentities($row['posturl']);?>" class="photography-images" alt=""/></figure><br>
                  <label><?php echo htmlentities($row['subcategory']);?></label>
                </div>
              </li>
              <?php $cnt++;
              } }
              }?>
            </ul>
          </div>
          <div class="single_post_content subcategory-photos">
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
        <?php include('includes/right-side.php');?>
        </aside>
      </div>
    </div>
  </section>
  <footer id="footer">
    <div class="footer_top">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInLeftBig">
            <h2>Flickr Images</h2>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInDown">
            <h2>Tag</h2>
            <ul class="tag_nav">
              <li><a href="#">Games</a></li>
              <li><a href="#">Sports</a></li>
              <li><a href="#">Fashion</a></li>
              <li><a href="#">Business</a></li>
              <li><a href="#">Life &amp; Style</a></li>
              <li><a href="#">Technology</a></li>
              <li><a href="#">Photo</a></li>
              <li><a href="#">Slider</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="footer_widget wow fadeInRightBig">
            <h2>Contact</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <address>
            Perfect News,1238 S . 123 St.Suite 25 Town City 3333,USA Phone: 123-326-789 Fax: 123-546-567
            </address>
          </div>
        </div>
      </div>
    </div>
    <div class="footer_bottom">
      <p class="copyright">Copyright &copy; 2045 <a href="index.php">NewsFeed</a></p>
      <p class="developer">Developed By Wpfreeware</p>
    </div>
  </footer>
</div>
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/js/wow.min.js"></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/jquery.li-scroller.1.0.js"></script> 
<script src="assets/js/jquery.newsTicker.min.js"></script> 
<script src="assets/js/jquery.fancybox.pack.js"></script> 
<script src="assets/js/custom.js"></script>
</body>
</html>