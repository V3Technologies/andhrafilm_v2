<?php
include('includes/config.php');
if(!empty($_POST["catid"]) && !empty($_POST["subcatid"]) && !empty($_POST["subcatname"])) 
{
    $id=intval($_POST['catid']);
    $subid=intval($_POST['subcatid']);
    $subcatname=$_POST["subcatname"];
$query=mysqli_query($con,"select tblgallery.id as pid,tblgallery.posturl as posturl,tblgallerycategory.GalleryCategoryName as category,tblgallerysubcategory.Subcategory as subcategory, tblgallery.PostingDate as postingdate from tblgallery left join tblgallerycategory on tblgallerycategory.id=tblgallery.CategoryId left join tblgallerysubcategory on tblgallerysubcategory.SubCategoryId=tblgallery.SubCategoryId where tblgallery.Is_Active=1 and tblgallery.SubCategoryId=$subid and tblgallery.CategoryId=$id order by tblgallery.id desc ");
$cnt=1;
?>
<h2><span> <?php echo $subcatname ?> Gallery</span></h2>
<span class="glyphicon glyphicon-arrow-left" style="color: #d083cf;" onClick="showallphotos()"></span>
<ul class="photograph_nav  wow fadeInDown">
<?php
while($row=mysqli_fetch_array($query))
{
?>        
    <li>
    <div class="photo_grid">
        <figure class="effect-layla singlephoto"> 
            <a class="fancybox-buttons" data-fancybox-group="button" href="admin/postimages/<?php echo htmlentities($row['posturl']);?>" title="<?php echo htmlentities($row['subcategory']);?>"> 
                <img src="admin/postimages/<?php echo htmlentities($row['posturl']);?>" style="object-fit: cover; width: 231px; height: 180px;" alt=""/>
            </a> 
        </figure><br>
    </div>
    </li>
            
<?php
}?> 
</ul>
<?php } ?>