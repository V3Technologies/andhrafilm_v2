<?php 
    $query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.ShortDescription as shortDescription,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join tblsubcategory on tblsubcategory.SubCategoryId=tblposts.SubCategoryId where tblposts.Is_Active=1 and tblposts.isExclusiveNews=1 order by tblposts.id desc LIMIT 1, 4");
    while ($row=mysqli_fetch_array($query)) {
    ?>
        <li>
            <div class="media wow fadeInDown"> <a href="pages/single_page.html" class="media-left"> <img alt="" src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>"> </a>
            <div class="media-body"> <a href="pages/single_page.html" class="catg_title"> <?php echo htmlentities($row['posttitle']);?></a> </div>
            </div>
        </li>
<?php } ?>