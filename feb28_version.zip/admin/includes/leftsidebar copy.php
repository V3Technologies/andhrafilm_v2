            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Breaking News </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-breaking-news.php">Add Breaking News</a></li>
                                    <li><a href="manage-breaking-news.php">Manage Breaking News</a></li>
                                </ul>
                            </li>              
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> News </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-post.php">Add News</a></li>
                                    <li><a href="manage-posts.php">Manage News</a></li>
                                     <li><a href="trash-posts.php">Trash News</a></li>
                                </ul>
                            </li>  
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-newscategory.php">Add Category</a></li>
                                    <li><a href="add-gallerycategories.php">Add Gallery Category</a></li>
                                    <li><a href="manage-newscategories.php">Manage Category</a></li>
                                    <li><a href="manage-gallerycategories.php">Manage Gallery Category</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Sub Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-newssubcategory.php">Add Sub Category</a></li>
                                    <li><a href="add-gallerysubcategory.php">Add Gallery Sub Category</a></li>
                                    <li><a href="manage-newssubcategories.php">Manage Sub Category</a></li>
                                    <li><a href="manage-gallerysubcategories.php">Manage Gallery Sub Category</a></li>
                                </ul>
                            </li> 
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Gallery </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-photos.php">Photos</a></li>
                                    <li><a href="manage-photos.php">Manage Photos</a></li>
                                    <li><a href="add-videos.php">Videos</a></li>
                                    <li><a href="manage-videos.php">Manage Videos</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Reviews </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-reviews.php">Add Reviews</a></li>
                                    <li><a href="manage-reviews.php">Manage Reviews</a></li>
                                     <li><a href="trash-reviews.php">Trash Reviews</a></li>
                                     <?php if($_SESSION['userrole'] == 1) { ?><li><a href="wfa-reviews.php">Waiting for Approval</a></li><?php } ?>
                                    <li><a href="approved-reviews.php">Approved Reviews</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Interviews</span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-interviews.php">Add Interview</a></li>
                                    <li><a href="manage-interview.php">Manage Interviews</a></li>
                                     <li><a href="trash-interviews.php">Trash Interviews</a></li>
                                     <?php if($_SESSION['userrole'] == 1) { ?><li><a href="wfa-interviews.php">Waiting for Approval</a></li><?php } ?>
                                    <li><a href="approved-interviews.php">Approved Interviews</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Comments </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <?php if($_SESSION['userrole'] == 1) { ?><li><a href="unapprove-comment.php">Waiting for Approval </a></li><?php } ?>
                                    <li><a href="approved-comments.php">Approved Comments</a></li>
                                </ul>
                            </li>  
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Advertisements </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-advertisement.php">Add Ads</a></li>
                                    <li><a href="manage-advertisement.php">Manage Ads</a></li>
                                    <?php if($_SESSION['userrole'] == 1) { ?><li><a href="unapprove-comment.php">Waiting for Approval </a></li><?php } ?>
                                    <li><a href="manage-comments.php">Approved Ads</a></li>
                                </ul>
                            </li>                   

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Pages </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="aboutus.php">About us</a></li>
                                    <li><a href="contactus.php">Contact us</a></li>
                                </ul>
                            </li>
                              

                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/> v3techub@gmail.com</p>
                    </div>

                </div>
                <!-- Sidebar -left -->

            </div>