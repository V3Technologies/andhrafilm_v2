

<?php
include('includes/config.php');
if(!empty($_POST["catid"] && !empty($_POST["subcatid"]))) 
{
    $id=intval($_POST['catid']);
    $subid=intval($_POST['subcatid']);
$query=mysqli_query($con,"select tblgallery.id as id,tblgallerysubcategory.SubCategoryId as subcategoryid,tblgallerycategory.GalleryCategoryName as category,tblgallerysubcategory.Subcategory as subcategory,tblgallery.PostUrl as imageurl,tblgallery.PostingDate as postingdate,tblgallery.UpdationDate as updationdate,tblgallery.Is_Active as status from tblgallery left join tblgallerycategory on tblgallerycategory.id=tblgallery.CategoryId left join tblgallerysubcategory on tblgallerysubcategory.SubCategoryId=tblgallery.SubCategoryId where tblgallery.Is_Active=1 and tblgallery.CategoryId=$id and tblgallerysubcategory.SubCategoryId=$subid");
$cnt=1;
$rowcount=mysqli_num_rows($query);
if($rowcount==0)
{
?>
<tr>

<td colspan="7" align="center"><h3 style="color:red">No record found</h3></td>
<tr>
<?php 
} else {
while($row=mysqli_fetch_array($query))
{
?>
 <tr>
<td scope="row"><?php echo htmlentities($cnt);?></td>
<td><img src="postimages/<?php echo htmlentities($row['imageurl']);?>" class="img-icon" alt="<?php echo htmlentities($row['subcategory']);?>"></td>
<td><?php echo htmlentities($row['postingdate']);?></td>
<td><?php echo htmlentities($row['updationdate']);?></td>
<td><a href="manage-photos.php?scid=<?php echo htmlentities($row['subcategoryid']);?>&&id=<?php echo htmlentities($row['id']);?>&&action=del"> <i class="fa fa-trash-o" style="color: #f05050"></i></a> </td>
</tr>
<?php $cnt++;
} }
}?>