<?php
include('includes/config.php');
if(!empty($_POST["id"])) 
{
    $id=intval($_POST['id']);
    echo "<script>alert($id');</script>";
    $query=mysqli_query($con,"update tblvideos set views= views +1 where id='$id' ");
    if($query)
    {
    $msg="About us  page successfully updated ";
    }
    else{
    $error="Something went wrong . Please try again.";    
    } 
}?>